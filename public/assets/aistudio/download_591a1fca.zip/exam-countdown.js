/**
 * PYQArchive Exam Countdown Banner v3.0
 * - Banner fixed at very top (above PYQ Archive header)
 * - Full countdown: Days / Hours / Minutes / Seconds
 * - Live tick every 1 second
 * - Uses existing Welcome overlay data (no duplicate popup)
 */
(function() {
    'use strict';

    /* ============================================================
       STORAGE KEYS (must match index.html welcome overlay)
       ============================================================ */
    const KEY_UNI = 'pyqarchive_selected_university';
    const KEY_SEM = 'pyqarchive_selected_semester';
    const KEY_SUBJ = 'pyqarchive_selected_subject';
    const KEY_BANNER_DISMISSED = 'pyq_exam_banner_dismissed_until';

    function getSaved() {
        try {
            return {
                uniId: localStorage.getItem(KEY_UNI) || null,
                semId: localStorage.getItem(KEY_SEM) || null,
                subjId: localStorage.getItem(KEY_SUBJ) || null,
                dismissedUntil: parseInt(localStorage.getItem(KEY_BANNER_DISMISSED) || '0', 10)
            };
        } catch (_) { return { uniId: null, semId: null, subjId: null, dismissedUntil: 0 }; }
    }

    function dismissBannerFor(hours) {
        try {
            const until = Date.now() + (hours * 60 * 60 * 1000);
            localStorage.setItem(KEY_BANNER_DISMISSED, String(until));
        } catch (_) {}
    }

    /* ============================================================
       STYLES — banner fixed at TOP of viewport
       ============================================================ */
    const style = document.createElement('style');
    style.textContent = `
        /* ===== BANNER — ABOVE HEADER ===== */
        .exam-countdown-banner {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1100;
            background: linear-gradient(135deg, #1a3a5c 0%, #2a5a8c 100%);
            color: #fff;
            padding: 7px 14px;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            box-shadow: 0 2px 12px rgba(0,0,0,.15);
            transform: translateY(-110%);
            transition: transform .4s cubic-bezier(.4,.2,.2,1);
            font-size: .88rem;
            line-height: 1.2;
        }
        .exam-countdown-banner.show {
            transform: translateY(0);
        }
        .exam-countdown-banner.urgent {
            background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
        }
        .exam-countdown-banner.soon {
            background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
        }
        .exam-countdown-banner.ongoing {
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
        }

        .exam-countdown-banner .ecb-inner {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 4px;
        }

        .exam-countdown-banner .ecb-icon {
            font-size: 1.05rem;
            flex-shrink: 0;
            animation: ecbPulse 2s ease-in-out infinite;
        }
        @keyframes ecbPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.15); }
        }

        .exam-countdown-banner .ecb-info {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
            font-size: .84rem;
        }
        .exam-countdown-banner .ecb-uni {
            opacity: .9;
            font-weight: 500;
        }
        .exam-countdown-banner .ecb-sep {
            opacity: .45;
            margin: 0 2px;
        }
        .exam-countdown-banner .ecb-sem {
            font-weight: 700;
        }

        /* ===== TIMER — D/H/M/S boxes ===== */
        .exam-countdown-banner .ecb-timer {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: rgba(255,255,255,.14);
            padding: 3px 10px;
            border-radius: 8px;
            border: 1px solid rgba(255,255,255,.22);
            margin-left: 4px;
        }
        .exam-countdown-banner .ecb-unit {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            min-width: 26px;
            line-height: 1;
        }
        .exam-countdown-banner .ecb-unit strong {
            font-size: .95rem;
            font-weight: 800;
            font-variant-numeric: tabular-nums;
            letter-spacing: -.02em;
        }
        .exam-countdown-banner .ecb-unit small {
            font-size: .55rem;
            opacity: .75;
            text-transform: uppercase;
            letter-spacing: .06em;
            font-weight: 600;
            margin-top: 1px;
        }
        .exam-countdown-banner .ecb-timer-label {
            font-size: .7rem;
            opacity: .8;
            font-weight: 600;
            margin-right: 3px;
            text-transform: uppercase;
            letter-spacing: .04em;
        }

        .exam-countdown-banner .ecb-actions {
            display: inline-flex;
            gap: 4px;
            flex-shrink: 0;
        }
        .exam-countdown-banner .ecb-close {
            background: rgba(255,255,255,.14);
            border: 1px solid rgba(255,255,255,.22);
            color: #fff;
            width: 22px;
            height: 22px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: .7rem;
            padding: 0;
            transition: background .2s, transform .15s;
            font-family: inherit;
        }
        .exam-countdown-banner .ecb-close:hover {
            background: rgba(255,255,255,.3);
            transform: rotate(90deg);
        }

        /* ===== BODY OFFSET (pushed down by banner height) ===== */
        body.has-exam-banner .header {
            top: var(--exam-banner-h, 40px) !important;
        }
        body.has-exam-banner {
            padding-top: var(--exam-banner-h, 40px);
        }

        /* ===== MOBILE ===== */
        @media (max-width: 600px) {
            .exam-countdown-banner {
                padding: 6px 10px;
                font-size: .78rem;
            }
            .exam-countdown-banner .ecb-inner {
                gap: 6px;
            }
            .exam-countdown-banner .ecb-info {
                font-size: .76rem;
                gap: 4px;
            }
            .exam-countdown-banner .ecb-timer {
                gap: 3px;
                padding: 2px 7px;
                margin-left: 2px;
            }
            .exam-countdown-banner .ecb-unit {
                min-width: 22px;
            }
            .exam-countdown-banner .ecb-unit strong {
                font-size: .82rem;
            }
            .exam-countdown-banner .ecb-unit small {
                font-size: .48rem;
            }
            .exam-countdown-banner .ecb-timer-label {
                display: none;
            }
            .exam-countdown-banner .ecb-uni {
                max-width: 110px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
        }
    `;
    document.head.appendChild(style);

    /* ============================================================
       STATE
       ============================================================ */
    let bannerEl = null;
    let tickInterval = null;
    let masterData = { universities: [], semesters: [], subjects: [] };
    let firebaseReady = false;
    let currentSchedule = null;
    let currentState = null;      // 'upcoming' | 'ongoing' | 'completed'
    let numEls = null;            // references to D/H/M/S <strong> elements
    let lastThreshold = null;     // track when we need to rebuild

    /* ============================================================
       HELPERS
       ============================================================ */
    function escapeHTML(s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m] || m));
    }

    function waitForFirebase() {
        return new Promise((resolve) => {
            const check = () => {
                if (window.firebase && window.firebase.apps && window.firebase.apps.length > 0) {
                    firebaseReady = true;
                    resolve();
                } else {
                    setTimeout(check, 100);
                }
            };
            check();
        });
    }

    async function loadMasterData() {
        const db = firebase.firestore();
        const [uniSnap, semSnap, subSnap] = await Promise.all([
            db.collection('universities').orderBy('name').get(),
            db.collection('semesters').orderBy('name').get(),
            db.collection('subjects').orderBy('name').get()
        ]);
        masterData.universities = uniSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        masterData.semesters = semSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        masterData.subjects = subSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    }

    async function fetchSchedule(uniId, semId) {
        try {
            const snap = await firebase.firestore()
                .collection('exam_schedules')
                .where('universityId', '==', uniId)
                .where('semesterId', '==', semId)
                .limit(1)
                .get();
            if (snap.empty) return null;
            const d = snap.docs[0].data();
            const start = d.startDate?.toDate ? d.startDate.toDate() : new Date(d.startDate);
            const end = d.endDate?.toDate ? d.endDate.toDate() : (d.endDate ? new Date(d.endDate) : start);
            if (isNaN(start.getTime())) return null;
            return { startDate: start, endDate: end };
        } catch (err) {
            console.error('[ExamCountdown] Fetch error:', err);
            return null;
        }
    }

    /* ============================================================
       LAYOUT ADJUSTMENT — push body/header down by banner height
       ============================================================ */
    function adjustLayout(show) {
        const body = document.body;
        if (show && bannerEl) {
            const h = bannerEl.offsetHeight;
            body.classList.add('has-exam-banner');
            body.style.setProperty('--exam-banner-h', h + 'px');
        } else {
            body.classList.remove('has-exam-banner');
            body.style.removeProperty('--exam-banner-h');
        }
    }

    /* ============================================================
       BANNER
       ============================================================ */
    function removeBanner() {
        if (tickInterval) { clearInterval(tickInterval); tickInterval = null; }
        if (bannerEl) {
            bannerEl.classList.remove('show');
            const el = bannerEl;
            setTimeout(() => el.remove(), 400);
            bannerEl = null;
        }
        adjustLayout(false);
    }

    function createBanner() {
        if (bannerEl) return bannerEl;
        bannerEl = document.createElement('div');
        bannerEl.className = 'exam-countdown-banner';
        bannerEl.id = 'examCountdownBanner';
        document.body.appendChild(bannerEl);
        return bannerEl;
    }

    /* ============================================================
       RENDER BANNER (full rebuild)
       ============================================================ */
    function renderBanner(uniName, semName, schedule) {
        const banner = createBanner();
        const now = Date.now();
        const start = schedule.startDate.getTime();
        const end = schedule.endDate ? schedule.endDate.getTime() : start;

        let cls = '';
        let state = 'upcoming';
        let timerLabel = 'until exam';

        if (now >= start && now <= end) {
            cls = 'ongoing';
            state = 'ongoing';
            timerLabel = 'remaining';
        } else if (now > end) {
            cls = '';
            state = 'completed';
            timerLabel = 'completed';
        } else {
            const daysLeft = Math.ceil((start - now) / 86400000);
            if (daysLeft <= 7) cls = 'urgent';
            else if (daysLeft <= 21) cls = 'soon';
        }

        currentSchedule = schedule;
        currentState = state;

        banner.className = 'exam-countdown-banner ' + cls;

        if (state === 'completed') {
            banner.innerHTML = `
                <div class="ecb-inner">
                    <span class="ecb-icon">✓</span>
                    <div class="ecb-info">
                        <span class="ecb-uni">${escapeHTML(uniName)}</span>
                        <span class="ecb-sep">·</span>
                        <span class="ecb-sem">${escapeHTML(semName)}</span>
                        <span class="ecb-sep">·</span>
                        <span style="opacity:.85">Exams completed</span>
                    </div>
                    <div class="ecb-actions">
                        <button type="button" class="ecb-close" title="Hide for 24 hours"><i class="fas fa-times"></i></button>
                    </div>
                </div>
            `;
            numEls = null;
        } else {
            banner.innerHTML = `
                <div class="ecb-inner">
                    <span class="ecb-icon">🎯</span>
                    <div class="ecb-info">
                        <span class="ecb-uni">${escapeHTML(uniName)}</span>
                        <span class="ecb-sep">·</span>
                        <span class="ecb-sem">${escapeHTML(semName)}</span>
                    </div>
                    <span class="ecb-timer">
                        <span class="ecb-timer-label" data-label>${timerLabel}</span>
                        <span class="ecb-unit"><strong data-u="d">0</strong><small>Days</small></span>
                        <span class="ecb-unit"><strong data-u="h">00</strong><small>Hrs</small></span>
                        <span class="ecb-unit"><strong data-u="m">00</strong><small>Min</small></span>
                        <span class="ecb-unit"><strong data-u="s">00</strong><small>Sec</small></span>
                    </span>
                    <div class="ecb-actions">
                        <button type="button" class="ecb-close" title="Hide for 24 hours"><i class="fas fa-times"></i></button>
                    </div>
                </div>
            `;
            // Store references to the number elements
            numEls = {
                d: banner.querySelector('[data-u="d"]'),
                h: banner.querySelector('[data-u="h"]'),
                m: banner.querySelector('[data-u="m"]'),
                s: banner.querySelector('[data-u="s"]'),
                label: banner.querySelector('[data-label]')
            };
            // Immediate first update
            updateCountdownValues();
        }

        // Close button
        banner.querySelector('.ecb-close').addEventListener('click', () => {
            dismissBannerFor(24);
            removeBanner();
        });

        // Show animation
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                banner.classList.add('show');
                adjustLayout(true);
                // Re-adjust after height is measurable
                setTimeout(() => adjustLayout(true), 50);
            });
        });

        // Start live tick
        startTick();
    }

    /* ============================================================
       LIVE COUNTDOWN — updates every second
       ============================================================ */
    function startTick() {
        if (tickInterval) clearInterval(tickInterval);
        tickInterval = setInterval(updateCountdownValues, 1000);
    }

    function updateCountdownValues() {
        if (!currentSchedule || !numEls) return;

        const now = Date.now();
        const start = currentSchedule.startDate.getTime();
        const end = currentSchedule.endDate ? currentSchedule.endDate.getTime() : start;

        let target, label;
        if (now < start) {
            target = start;
            label = 'until exam';
        } else if (now <= end) {
            target = end;
            label = 'remaining';
        } else {
            // Just crossed to completed — rebuild
            if (currentState !== 'completed') {
                rebuildBanner();
            }
            return;
        }

        const diff = target - now;

        // Crossed threshold — need rebuild
        if (currentState === 'upcoming' && now >= start) {
            rebuildBanner();
            return;
        }

        const days = Math.floor(diff / 86400000);
        const hours = Math.floor((diff % 86400000) / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);

        if (numEls.d) numEls.d.textContent = days;
        if (numEls.h) numEls.h.textContent = String(hours).padStart(2, '0');
        if (numEls.m) numEls.m.textContent = String(mins).padStart(2, '0');
        if (numEls.s) numEls.s.textContent = String(secs).padStart(2, '0');
        if (numEls.label && numEls.label.textContent !== label) {
            numEls.label.textContent = label;
        }

        // Update color class dynamically
        if (currentState === 'upcoming' && bannerEl) {
            const daysLeft = Math.ceil(diff / 86400000);
            let cls = '';
            if (daysLeft <= 7) cls = 'urgent';
            else if (daysLeft <= 21) cls = 'soon';
            const desired = 'exam-countdown-banner ' + cls + ' show';
            if (bannerEl.className !== desired) {
                bannerEl.className = desired;
            }
        }
    }

    async function rebuildBanner() {
        const saved = getSaved();
        if (!saved.uniId || !saved.semId) return;
        const uni = masterData.universities.find(u => u.id === saved.uniId);
        const sem = masterData.semesters.find(s => s.id === saved.semId);
        if (!uni || !sem) return;
        const schedule = await fetchSchedule(saved.uniId, saved.semId);
        if (!schedule) { removeBanner(); return; }
        renderBanner(uni.name, sem.name, schedule);
    }

    /* ============================================================
       CHECK & SHOW
       ============================================================ */
    async function checkAndShowBanner() {
        if (!firebaseReady) return;
        const saved = getSaved();
        if (!saved.uniId || !saved.semId) {
            removeBanner();
            return;
        }
        if (saved.dismissedUntil > Date.now()) {
            removeBanner();
            return;
        }

        const uni = masterData.universities.find(u => u.id === saved.uniId);
        const sem = masterData.semesters.find(s => s.id === saved.semId);
        if (!uni || !sem) {
            removeBanner();
            return;
        }

        const schedule = await fetchSchedule(saved.uniId, saved.semId);
        if (!schedule) {
            removeBanner();
            return;
        }

        renderBanner(uni.name, sem.name, schedule);
    }

    /* ============================================================
       WATCH FOR SELECTION CHANGES
       ============================================================ */
    function watchStorageChanges() {
        window.addEventListener('storage', (e) => {
            if (e.key === KEY_UNI || e.key === KEY_SEM || e.key === KEY_SUBJ) {
                checkAndShowBanner();
            }
        });

        window.addEventListener('pyq:selection-changed', () => {
            checkAndShowBanner();
        });

        // Fallback poll (every 2 sec) — cheap localStorage read
        let lastKey = '';
        setInterval(() => {
            const s = getSaved();
            const current = `${s.uniId || ''}|${s.semId || ''}|${s.dismissedUntil}`;
            if (current !== lastKey) {
                lastKey = current;
                checkAndShowBanner();
            }
        }, 2000);
    }

    /* ============================================================
       BOOT
       ============================================================ */
    async function boot() {
        try {
            await waitForFirebase();
            await loadMasterData();
            watchStorageChanges();
            await checkAndShowBanner();
            console.log('[ExamCountdown] ✅ Ready');
        } catch (err) {
            console.error('[ExamCountdown] Boot error:', err);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }

    window.PYQExamCountdown = {
        refresh: checkAndShowBanner,
        remove: removeBanner
    };
})();