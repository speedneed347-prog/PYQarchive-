(function(){
    'use strict';

    const currentPage = location.pathname.split('/').pop() || 'index.html';
    const links = [
        { href: 'index.html', label: 'Home' },
        { href: 'universities-list.html', label: 'Universities' },
        { href: 'search.html', label: 'Search' },
        { href: 'trending.html', label: '🔥 Trending', cls: 'trending-link' },
        { href: 'study-tools.html', label: '📚 Study Tools', cls: 'study-tools-link' },
        { href: 'request.html', label: 'Request Paper' },
        { href: 'resources.html', label: 'Resources' },
        { href: 'about.html', label: 'About' },
        { href: 'contact.html', label: 'Contact' },
        { href: 'faq.html', label: 'FAQ' }
    ];
    const mobileLinks = [
        ...links,
        { href: 'request-status.html', label: 'Request Status' }
    ];

    function linkHtml(l, isMobile) {
        const active = (l.href === currentPage) ? ' active' : '';
        const cls = (l.cls || '') + active;
        return `<a href="${l.href}"${cls ? ` class="${cls.trim()}"` : ''}>${l.label}</a>`;
    }

    function inject() {
        const desktopNav = document.querySelector('.nav-desktop');
        if (desktopNav) desktopNav.innerHTML = links.map(l => linkHtml(l, false)).join('');

        const mobileNav = document.querySelector('.mobile-menu-inner nav');
        if (mobileNav) {
            // Keep any existing special buttons (e.g. mobile-search-btn) outside
            mobileNav.innerHTML = mobileLinks.map(l => linkHtml(l, true)).join('');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', inject);
    } else {
        inject();
    }
})();